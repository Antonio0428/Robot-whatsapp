const express = require('express');
const bodyParser = require('body-parser');
const axios = require('axios');
const nodemailer = require('nodemailer');
const twilio = require('twilio');
const mysql = require('mysql2');
const fs = require('fs');
const path = require('path');
const app = express();
const port = 3020;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Configuração do banco de dados MySQL
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '040494@idonia#',
    database: 'vfs_bot'
});

connection.connect((err) => {
    if (err) {
        console.error('Erro ao conectar ao banco de dados MySQL:', err);
        registrarLog(`Erro ao conectar ao banco de dados MySQL: ${err.message}`);
        return;
    }
    console.log('Conectado ao banco de dados MySQL');
});

// Função para registrar logs
function registrarLog(mensagem) {
    const data = new Date().toISOString();
    fs.appendFile('logs.txt', `${data} - ${mensagem}\n`, (err) => {
        if (err) throw err;
    });
}

// Rota para exibir o formulário de captura de dados
app.get('/', (req, res) => {
    const filePath = path.join(__dirname, 'index.html');
    console.log('Servindo arquivo:', filePath);
    res.sendFile(filePath);
});

// Rota para processar o formulário de captura de dados
app.post('/agendar', async (req, res) => {
    const userData = req.body;
    try {
        console.log('Dados recebidos:', userData);
        registrarLog(`Dados recebidos: ${JSON.stringify(userData)}`);
        
        const disponibilidade = await verificarDisponibilidade(userData.dataPreferencial);
        console.log('Disponibilidade:', disponibilidade);
        registrarLog(`Disponibilidade: ${JSON.stringify(disponibilidade)}`);
        
        if (disponibilidade.disponivel) {
            const agendamentoInfo = await agendarVisto(userData);
            console.log('Agendamento realizado:', agendamentoInfo);
            registrarLog(`Agendamento realizado: ${JSON.stringify(agendamentoInfo)}`);
            
            await enviarEmail(userData, agendamentoInfo);
            await enviarWhatsApp(userData, agendamentoInfo);
            await salvarDados(userData, agendamentoInfo);
            
            registrarLog(`Agendamento realizado com sucesso para ${userData.nomeCompleto}`);
            res.send("Agendamento realizado com sucesso!");
        } else {
            registrarLog(`Data não disponível para ${userData.nomeCompleto}`);
            res.send("Data não disponível. Por favor, escolha outra data.");
        }
    } catch (error) {
        console.error('Erro ao processar agendamento:', error);
        registrarLog(`Erro ao processar agendamento para ${userData.nomeCompleto}: ${error.message}`);
        res.status(500).send("Erro ao processar agendamento. Tente novamente mais tarde.");
    }
});

// Função para verificar disponibilidade de datas na VFS Global API
async function verificarDisponibilidade(dataPreferencial) {
    const apiUrl = 'https://api.vfsglobal.com/agendamento';
    const response = await axios.get(`${apiUrl}?data=${dataPreferencial}`);
    return response.data;
}

// Função para agendar visto
async function agendarVisto(userData) {
    const apiUrl = 'https://api.vfsglobal.com/agendamento';
    const response = await axios.post(apiUrl, userData);
    return response.data;
}

// Função para enviar email de confirmação
async function enviarEmail(userData, agendamentoInfo) {
    const transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
            user: 'antoniomanueldossantos.dev@gmail.com',
            pass: '040494@idonia#'
        }
    });

    const mailOptions = {
        from: 'antoniomanueldossantos.dev@gmail.com',
        to: userData.email,
        subject: 'Confirmação de Agendamento de Visto',
        text: `Olá ${userData.nomeCompleto},\nSeu agendamento para o visto foi confirmado.\nData: ${agendamentoInfo.data}\nHora: ${agendamentoInfo.hora}`
    };

    await transporter.sendMail(mailOptions);
}

// Função para enviar mensagem de confirmação via WhatsApp
async function enviarWhatsApp(userData, agendamentoInfo) {
    const client = twilio('your_twilio_account_sid', 'your_twilio_auth_token');

    await client.messages.create({
        body: `Seu agendamento para o visto foi confirmado para ${agendamentoInfo.data} às ${agendamentoInfo.hora}.`,
        from: 'whatsapp:+244942893918',
        to: userData.whatsapp
    });
}

// Função para salvar dados no banco de dados MySQL
async function salvarDados(userData, agendamentoInfo) {
    const query = 'INSERT INTO agendamentos (nomeCompleto, dataNascimento, nacionalidade, tipoVisto, dataPreferencial, email, whatsapp, dataAgendamento, horaAgendamento) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)';
    const values = [userData.nomeCompleto, userData.dataNascimento, userData.nacionalidade, userData.tipoVisto, userData.dataPreferencial, userData.email, userData.whatsapp, agendamentoInfo.data, agendamentoInfo.hora];
    connection.query(query, values, (err, results) => {
        if (err) {
            console.error('Erro ao salvar dados no banco de dados MySQL:', err);
            registrarLog(`Erro ao salvar dados no banco de dados MySQL: ${err.message}`);
            throw err;
        }
        console.log('Dados salvos no banco de dados MySQL');
    });
}

// Iniciar o servidor
app.listen(port, () => {
    console.log(`Servidor rodando em http://localhost:${port}`);
});
